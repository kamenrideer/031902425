from bs4 import BeautifulSoup
import re
import urllib.request
import datetime
from pyecharts.charts import Map
from pyecharts import options as opts
import os
import xlsxwriter
import time
from openpyxl import load_workbook
workbook = xlsxwriter.Workbook('yiqing.xlsx')
sheet = workbook.add_worksheet('yiqing')
pro_list = [
        '河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽',
        '福建', '江西', '山东', '河南', '湖北', '湖南', '广东', '海南',
        '四川', '贵州', '云南', '陕西', '甘肃', '青海', '北京', '天津',
        '上海', '重庆', '内蒙古', '广西', '西藏', '宁夏', '新疆'
    ]
k = 1
for j in pro_list:
    sheet.write(k, 0, j)
    k += 1
# 输入省份，j为行k为列

urlm = 'http://www.nhc.gov.cn/'
# url模板简称urlm
index_urlm = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd'
# 爬取目录用到的参数就在前面加上index
headers = {
    'Cookie': 'yfx_c_g_u_id_10006654=_ck22091520340616458941354037551; sVoELocvxVW0S=5Tcu_XbLqQLkwxP27cU.wiCxQDqiS.epE8S4xzDDw.atOPp.jVHvUtyWdtyKWn2xb5w8bDyA28_m6rpjQ_QY5eG; insert_cookie=91349450; sVoELocvxVW0T=53npK3bW9KtAqqqDkpGEZzGKrfCaG6Vh7VhtAceG6xhcGAOm9v8FQGNUcR1W33tKi02tHzzmzSyDm1UnBiJhdv6M1ZsIKcg5SSVY16zxd1oGo261HayCpd4qJ3mPK3pazGmzQt24JOydwyrOyx1ageZVlykbkNxtYy3gBoJWn6z89Go4WkZIV8qtTkvtMqlIwoiPgAwhQiaFyLVw1jZmt5MVQkMT00w5U1N7hq4JQxq4VP4v5FQBWmc9AaioVBOANlo8an7ydEFlc7PpvmoRhJw; yfx_f_l_v_t_10006654=f_t_1663245246639__r_t_1663304128824__v_t_1663328430395__r_c_1; security_session_verify=e29fd081e7512c4081c935b3ed9687b1',
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36'
}

lie = 0
# 输入第几列数据
for leaf in range(1, 42):
    # 先爬取目录信息
    if leaf > 1:
        index_url = index_urlm+'_'+str(leaf)+'.shtml'
    else:
        index_url = index_urlm+'.shtml'
    index_request = urllib.request.Request(url=index_url, headers=headers)
    index_response = urllib.request.urlopen(index_request)
    index_soup = BeautifulSoup(index_response.read().decode('utf-8'), 'html.parser')
    # 接下来输入时间
    Time = index_soup.select('.ml')
    num = -1
    for t in Time:
        time.sleep(1)
        # 减慢爬虫速度
        num += 1
        lie += 1
        b = datetime.datetime.strptime(Time[num].get_text(), "%Y-%m-%d")
        c = b - datetime.timedelta(days=1)
        d = c.strftime("%Y-%m-%d")
        # 将时间数据爬出来需要减一天才得到正确时间
        sheet.write(0, lie, d)
        # 以上输入时间
        houzhui = index_soup.find_all('a')[num+2]
        url = urlm+houzhui['href']
        request = urllib.request.Request(url=url, headers=headers)
        response = urllib.request.urlopen(request)
        soup = BeautifulSoup(response.read().decode('utf-8'), 'html.parser')
        obj = soup.select('.con')[0]
        text = obj.get_text()
        hang = 1
        for j in pro_list:
            Sum = 0
            res1 = re.search('新增确诊病例.*?例。其中境外输入病例.*?' + j + '(\d+)' + '.*?本土', text)
            res2 = re.search('新增确诊病例.*?本土病例.*?' + j + '(\d+)', text)
            if res1 != None:
                Sum += int(res1.group(1))
            if res2 != None:
                Sum += int(res2.group(1))
            sheet.write(hang, lie, Sum)
            hang += 1
            # 输入数据

workbook.close()

# 以上爬数据并保存
# 以下读数据可视化

xlsx = load_workbook("yiqing.xlsx")
booksheet = xlsx.active
rows = booksheet.max_row
cols = booksheet.max_column

time_schedule = {}
for col in range(2, cols+1):
    time_schedule[booksheet.cell(1, col).value] = col
    # 将日期与列数一一对应
check = 'Y'
while check == 'Y':
    print('请输入想要查询的日期:')
    print('(注：输入格式为xxxx-xx-xx,一旦输错将退出程序,例:2022-09-17)')
    command = input()
    t = time_schedule.setdefault(command, 'None')
    # 用来看你查哪天
    if t == 'None':
        print('格式或范围错误')
        check = 'N'
    else:
        province_distribution = {}
        for row in range(2, rows+1):
            province_distribution[pro_list[row-2]] = booksheet.cell(row, t).value

        provice = list(province_distribution.keys())
        values = list(province_distribution.values())

        c = (
            Map()
            .add("每日新增", [list(z) for z in zip(provice, values)], "china")
            .set_global_opts(title_opts=opts.TitleOpts(title="中国地图"))
            .render()
        )
        # 打开html
        os.system("render.html")
        print('输入Y继续查询')
        check = input()
